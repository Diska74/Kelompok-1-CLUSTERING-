import pandas as pd
from ucimlrepo import fetch_ucirepo
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from kneed import KneeLocator
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA

# fetch dataset
wholesale_customers = fetch_ucirepo(id=292)

# data (as pandas dataframes)
X = wholesale_customers.data.features
y = wholesale_customers.data.targets

# metadata
print(wholesale_customers.metadata)

# variable information
print(wholesale_customers.variables)

data = pd.DataFrame(X)
display(data)

# Langkah 2: Data Cleansing
# Menghapus kolom 'Channel' untuk fokus pada atribut pembelian produk
data_clustering = data.drop(columns=['Channel'])

# Normalisasi data (standarisasi) menggunakan StandardScaler
scaler = StandardScaler()
data_scaled = scaler.fit_transform(data_clustering)

print("Dataset setelah standarisasi:")
print(data_scaled[:])
# PCA (Principal Component Analysis) untuk mengurangi dimensi data
pca = PCA(n_components=2)
pca_components = pca.fit_transform(data_scaled)
df_pca = pd.DataFrame(pca_components, columns=['P1','P2'])
print(df_pca)
# Menampilkan varians yang dijelaskan oleh setiap komponen
explained_variance = pca.explained_variance_ratio_
print("Varians yang dijelaskan oleh setiap komponen PCA:")
for i, var in enumerate(explained_variance):
    print(f"Komponen {i+1}: {var:.4f} ({var*100:.2f}%)")
    # Langkah 4: Menentukan jumlah kluster optimal menggunakan Metode Elbow
inertia = []  # Menyimpan nilai inertia untuk berbagai jumlah kluster
k_range = range(1, 11)  # Mencoba jumlah kluster dari 1 hingga 10

for k in k_range:
    kmeans = KMeans(n_clusters=k, random_state=42)
    kmeans.fit(data_scaled)
    inertia.append(kmeans.inertia_)

# Visualisasi Metode Elbow
plt.figure(figsize=(8, 6))
plt.plot(k_range, inertia, marker='o')
plt.title('Metode Elbow untuk Menentukan Jumlah Kluster')
plt.xlabel('Jumlah Kluster')
plt.ylabel('Inertia')
plt.show()
# Find the optimal k using KneeLocator
knee = KneeLocator(range(1, 11), inertia, curve="convex", direction="decreasing")
k_optimal = knee.elbow
print(f"Optimal k: {k_optimal}")
# Langkah 5: Melakukan clustering dengan K-Means
kmeans = KMeans(n_clusters=k_optimal, random_state=42)
data['Cluster'] = kmeans.fit_predict(data_scaled)

# Langkah 6: Analisis Hasil Klustering

# Menambahkan kolom Cluster ke dataset untuk analisis
# Analisis berdasarkan mean pembelian untuk setiap kluster
cluster_summary = data.groupby('Cluster').mean()
cluster_summary = cluster_summary.drop('Channel', axis=1)  # Remove channel column

# Tampilkan ringkasan dari tiap kluster
print(cluster_summary)
# Get centroids and add random noise to spread them out
centroids = kmeans.cluster_centers_
centroids_pca = pca.transform(centroids)  # Transform centroids to PCA space
noise = np.random.normal(0, 0.1, centroids_pca.shape)  # Adjust the second parameter for more/less spread
centroids_spread = centroids_pca + noise
# Visualisasi Kluster dengan PCA
plt.figure(figsize=(8, 6))
sns.scatterplot(x=pca_components[:, 0], y=pca_components[:, 1], hue=kmeans.labels_, palette='Set1', s=100, alpha=0.7)
plt.scatter(centroids_spread[:, 0], centroids_spread[:, 1], s=100, c='black', marker='X', label='Spread Centroids')  # Plot spread centroids
plt.title('Visualisasi Kluster dengan PCA')
plt.xlabel('Komponen PCA 1')
plt.ylabel('Komponen PCA 2')
plt.legend()
plt.grid()
plt.show()

# Assuming you have a pandas DataFrame called 'df' with your data
# and 'kmeans' is your fitted KMeans model

# Get the cluster labels
cluster_labels = kmeans.labels_

# Create a DataFrame to count the members in each cluster
cluster_counts = pd.DataFrame(cluster_labels, columns=['Cluster']).value_counts()

# Sort the clusters by their count
cluster_counts = cluster_counts.sort_index()

# Display the results in a table format
print(cluster_counts.to_string())
# Langkah 7: Analisis Rata-rata Pembelian per Kluster
# Menghitung rata-rata pembelian produk untuk setiap kluster
cluster_summary = data.groupby('Cluster').mean()
cluster_summary = cluster_summary.drop('Channel', axis=1)

# Tampilkan ringkasan rata-rata pembelian per kluster
print("Rata-rata Pembelian Produk per Kluster:")
print(cluster_summary)
# Langkah 8: Analisis Pembelian Produk per Kluster
# Kita dapat melihat perbandingan pembelian produk per kluster menggunakan rata-rata
# Berikut adalah perbandingan pembelian rata-rata dari beberapa kategori produk
product_columns = ['Fresh', 'Milk', 'Grocery', 'Frozen', 'Detergents_Paper', 'Delicassen']
product_comparison = cluster_summary[product_columns]

# Tampilkan perbandingan pembelian produk per kluster
print("Perbandingan Pembelian Produk per Kluster:")
print(product_comparison)

# Visualisasi pembelian produk untuk tiap kluster
product_comparison.T.plot(kind='bar', figsize=(14, 8), colormap='Set2')
plt.title('Perbandingan Pembelian Produk per Kluster')
plt.xlabel('Produk')
plt.ylabel('Rata-rata Pembelian')
plt.xticks(rotation=45)
plt.legend(title='Kluster')
plt.tight_layout()
plt.show()